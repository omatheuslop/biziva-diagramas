import {cp,mkdir,rename,rm,mkdtemp,readFile,stat} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {tmpdir} from 'node:os';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const host=fileURLToPath(new URL('.',import.meta.url));
const pin=JSON.parse(await readFile(join(host,'native-source.json'),'utf8'));
if(pin.repository!=='https://github.com/omatheuslop/biziva-diagramas.git'||!/^([a-f0-9]{40})$/.test(pin.commit)||pin.directory!=='src/main/webapp')throw Error('Invalid pinned source');
const run=(args,cwd)=>{const p=spawnSync('git',['-c','core.hooksPath=/dev/null',...args],{cwd,encoding:'utf8'});if(p.status!==0)throw Error('Native source checkout failed');return p.stdout.trim();};
let root=resolve(process.argv[2]||join(host,'..')),temporary;
try{
 if(!await stat(join(root,pin.directory)).then(s=>s.isDirectory()).catch(()=>false)){
  temporary=await mkdtemp(join(tmpdir(),'biziva-diagramas-native-'));root=temporary;
  run(['init','.'],root);run(['fetch','--depth=1',pin.repository,pin.commit],root);
  if(run(['rev-parse','FETCH_HEAD'],root)!==pin.commit)throw Error('Source revision mismatch');
  run(['checkout','--detach','FETCH_HEAD'],root);
 }
 const target=join(host,'public');await rm(target,{recursive:true,force:true});await mkdir(target,{recursive:true});
 await cp(join(root,pin.directory),target,{recursive:true,filter:source=>!source.split(/[\\/]/).includes('WEB-INF')&&!source.endsWith('.jsp')});
 await rename(join(target,'index.html'),join(target,'native-index.html'));
 console.log('Native editor prepared from pinned complete source; servlet backend is not exposed as static files.');
}finally{if(temporary)await rm(temporary,{recursive:true,force:true});}

await import('./apply-branding.mjs');
