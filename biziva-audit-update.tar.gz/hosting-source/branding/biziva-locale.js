// Native locale default. Explicit URL and saved user preferences win.
(function(){
  if(new URLSearchParams(location.search).has('lang'))return;
  try{const saved=JSON.parse(localStorage.getItem('.drawio-config')||'null');if(saved&&saved.language)return;}catch{}
  window.mxLanguage=window.mxLanguage||'pt-br';
})();
