import{readFile,writeFile,copyFile}from'node:fs/promises';const root=new URL('./',import.meta.url);await copyFile(new URL('branding/shell.html',root),new URL('public/biziva-shell.html',root));for(const f of ['biziva-theme.css','biziva-favicon.svg'])await copyFile(new URL('branding/'+f,root),new URL('public/'+f,root));const file=new URL('public/native-index.html',root);let s=await readFile(file,'utf8');if(!s.includes('/biziva-theme.css'))s=s.replace('</head>','<link rel="stylesheet" href="/biziva-theme.css"><link rel="icon" href="/biziva-favicon.svg" type="image/svg+xml"></head>');await writeFile(file,s);

await copyFile(new URL('branding/biziva-locale.js',root),new URL('public/biziva-locale.js',root));
let localized=await readFile(file,'utf8');
if(!localized.includes('src="/biziva-locale.js"'))localized=localized.replace('<script src="js/bootstrap.js"></script>','<script src="/biziva-locale.js"></script><script src="js/bootstrap.js"></script>');
await writeFile(file,localized);
